                             generic-prettyprinter

   Displays a variety of files in a canonical form. Trivial prettyprinters
   for lots of kinds of files. Really easy to extend.
